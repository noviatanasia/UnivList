import React, { Component } from 'react'
import Card from './CardUI';
import img1 from '../assets/img1.jpg'
class Cards extends Component {
  render() {
    return (
      <div className="container-fluid d-flex justify-content-center">
        <div className="class">
          <div className="class col-md-4">
            <Card imgsrc={img1} title='UI' />
          </div>
          <div className="class col-md-4">
            <Card imgsrc={img1} title='Sunib' />
          </div>
          <div className="class col-md-4">
            <Card imgsrc={img1} title='ASD' />
          </div>
        </div>
      </div>
    )
  }
}