import React, { Component } from 'react'
import "./card-style.css"
import img1 from './assets/img1.jpg'
import Card from 'react-bootstrap/Card'
import CardDeck from 'react-bootstrap/CardDeck'
import CardColumns from 'react-bootstrap/CardColumns'



export const CardUI = props => {
  return (
    <CardDeck>
      <div className="row"></div>
      <div className="card text-center">
        <div className="container-fluid d-flex justify-content-center">
          <div className="row">
            <Card>
              <div className="class col-md-12">
                <div className="overflow">
                  <img src={img1} alt="Image 1" className="card-img-top" />
                </div>
                <div className="card-body text-dark">
                  <h4 className="card-title">Middle East University</h4>
                  <p className="card-text text-secondary">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus molestias tempora quo laboriosam eum deserunt atque mollitia, voluptatibus quia placeat sed saepe quibusdam rerum tenetur ratione iure veniam laudantium iste illum nostrum dolorem dolorum omnis! Ipsum nobis excepturi ducimus numquam del
        </p>
                  <a href="http://www.meu.edu.jo/" className="btn btn-outline-success">Go Anywhere</a>
                </div>
              </div>
            </Card>

            <Card>
              <div className="class col-md-12">
                <div className="overflow">
                  <img src={img1} alt="Image 2" className="card-img-top" />
                </div>
                <div className="card-body text-dark">
                  <h4 className="card-title">Middle East Technical University</h4>
                  <p className="card-text text-secondary">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus molestias tempora quo laboriosam eum deserunt atque mollitia, voluptatibus quia placeat sed saepe quibusdam rerum tenetur ratione iure veniam laudantium iste illum nostrum dolorem dolorum omnis! Ipsum nobis excepturi ducimus numquam del
        </p>
                  <a href="http://www.odtu.edu.tr/" className="btn btn-outline-success">Go Anywhere</a>
                </div>
              </div>
            </Card>

            <Card>
              <div className="class col-md-12">
                <div className="overflow">
                  <img src={img1} alt="Image 3" className="card-img-top" />
                </div>
                <div className="card-body text-dark">
                  <h4 className="card-title">Middle Tennessee State University</h4>
                  <p className="card-text text-secondary">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus molestias tempora quo laboriosam eum deserunt atque mollitia, voluptatibus quia placeat sed saepe quibusdam rerum tenetur ratione iure veniam laudantium iste illum nostrum dolorem dolorum omnis! Ipsum nobis excepturi ducimus numquam del
        </p>
                  <a href="http://www.mtsu.edu/" className="btn btn-outline-success">Go Anywhere</a>
                </div>
              </div>
            </Card>

            {/* <Card>
              <div className="class col-md-12">
                <div className="overflow">
                  <img src={img1} alt="Image 4" className="card-img-top" />
                </div>
                <div className="card-body text-dark">
                  <h4 className="card-title">Middle Georgia State College</h4>
                  <p className="card-text text-secondary">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus molestias tempora quo laboriosam eum deserunt atque mollitia, voluptatibus quia placeat sed saepe quibusdam rerum tenetur ratione iure veniam laudantium iste illum nostrum dolorem dolorum omnis! Ipsum nobis excepturi ducimus numquam del
        </p>
                  <a href="http://www.mga.edu/" className="btn btn-outline-success">Go Anywhere</a>
                </div>
              </div>
            </Card>

            <Card>
              <div className="class col-md-12">
                <div className="overflow">
                  <img src={img1} alt="Image 5" className="card-img-top" />
                </div>
                <div className="card-body text-dark">
                  <h4 className="card-title">Middlesex University</h4>
                  <p className="card-text text-secondary">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus molestias tempora quo laboriosam eum deserunt atque mollitia, voluptatibus quia placeat sed saepe quibusdam rerum tenetur ratione iure veniam laudantium iste illum nostrum dolorem dolorum omnis! Ipsum nobis excepturi ducimus numquam del
        </p>
                  <a href="http://www.mdx.ac.uk/" className="btn btn-outline-success">Go Anywhere</a>
                </div>
              </div>
            </Card>

            <Card>
              <div className="class col-md-12">
                <div className="overflow">
                  <img src={img1} alt="Image 6" className="card-img-top" />
                </div>
                <div className="card-body text-dark">
                  <h4 className="card-title">Middlebury College</h4>
                  <p className="card-text text-secondary">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus molestias tempora quo laboriosam eum deserunt atque mollitia, voluptatibus quia placeat sed saepe quibusdam rerum tenetur ratione iure veniam laudantium iste illum nostrum dolorem dolorum omnis! Ipsum nobis excepturi ducimus numquam del
        </p>
                  <a href="http://www.middlebury.edu/" className="btn btn-outline-success">Go Anywhere</a>
                </div>
              </div>
            </Card> */}

          </div>
        </div>
      </div>
    </CardDeck>

  );
}

// export default CardUI
