import React, { Component } from 'react'
import "./card-style.css"
const UnivList = props => {
  return (
    <div className="card text-center">
      <div className="overflow">
        <img src={props.imgsrc} alt="Image 1" className="card-img-top" />
      </div>
      <div className="card-body text-dark">
        <h4 className="card-title">{props.title}</h4>
        <p className="card-text text-secondary">
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus molestias tempora quo laboriosam eum deserunt atque mollitia, voluptatibus quia placeat sed saepe quibusdam rerum tenetur ratione iure veniam laudantium iste illum nostrum dolorem dolorum omnis! Ipsum nobis excepturi ducimus numquam delectus? Explicabo aspernatur beatae, assumenda ab consectetur voluptates doloribus dolorem veniam quibusdam pariatur sint cum expedita tempore adipisci. Molestias sit in similique cupiditate nostrum ab ducimus vel omnis, quae repellendus? Aliquid totam molestiae ipsam quia vel optio. Facilis sed veniam aut animi sequi eaque enim voluptatum culpa libero, quibusdam ratione ducimus omnis natus nulla aspernatur exercitationem sapiente, sit suscipit provident incidunt eligendi ad ab, nobis quis? Nesciunt distinctio quam nulla in culpa, dolor ducimus eligendi voluptatum deserunt totam esse iste animi maxime placeat dolore voluptates quas praesentium itaque ipsam quos! Sequi consequatur veniam quos omnis optio excepturi est culpa quidem dicta ducimus magnam assumenda incidunt ipsam officiis dolorum impedit reprehenderit praesentium quaerat, maiores doloremque modi quibusdam cumque? Consequatur temporibus iusto dolorem. Placeat optio inventore saepe vel, dolores cumque quia tempore at laborum consectetur sunt explicabo culpa corporis quidem, quam fugiat. Sapiente architecto vero at, inventore, minus eum ab fugiat dolorum quo fuga unde voluptatibus enim doloribus voluptas nobis quasi ipsa.
        </p>
        <a href="#" className="btn btn-outline-success">Go Anywhere</a>
      </div>
    </div>
  );
}

export default UnivList
