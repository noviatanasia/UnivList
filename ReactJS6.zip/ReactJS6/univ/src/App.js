// import React from 'react';
// import logo from './logo.svg';
// import './App.css';
// import * as ReactBootsrap from 'react-bootstrap'
// import Page1 from './components/Page1'
// import Page2 from './components/Page2'
// import Page3 from './components/Page3'
// import Page4 from './components/Page4'
// import Counter from './components/Counter';
// import FunctionClick from './components/FunctionClick';
// import ClassClick from './components/ClassClick';
// import EventBind from './components/EventBind';
// import ParentComponent from './components/ParentComponent';
// import UserGreeting from './components/UserGreeting';

// function App() {
//   return (
//     <div className="App">
//       <ReactBootsrap.Navbar collapseOnSelect expand="sm" bg="dark" variant="dark">
//         <ReactBootsrap.Navbar.Brand href="#home">UNIV</ReactBootsrap.Navbar.Brand>
//         <ReactBootsrap.Navbar.Toggle aria-controls="responsive-navbar-nav" />
//         <ReactBootsrap.Navbar.Collapse id="responsive-navbar-nav">
//           <ReactBootsrap.Nav className="mr-auto">
//             <ReactBootsrap.Nav.Link href="#features">Features</ReactBootsrap.Nav.Link>
//             <ReactBootsrap.Nav.Link href="#pricing">Pricing</ReactBootsrap.Nav.Link>
//             <ReactBootsrap.NavDropdown title="Dropdown" id="collasible-nav-dropdown">
//               <ReactBootsrap.NavDropdown.Item href="#action/3.1">Action</ReactBootsrap.NavDropdown.Item>
//               <ReactBootsrap.NavDropdown.Item href="#action/3.2">Another action</ReactBootsrap.NavDropdown.Item>
//               <ReactBootsrap.NavDropdown.Item href="#action/3.3">Something</ReactBootsrap.NavDropdown.Item>
//               <ReactBootsrap.NavDropdown.Divider />
//               <ReactBootsrap.NavDropdown.Item href="#action/3.4">Separated link</ReactBootsrap.NavDropdown.Item>
//             </ReactBootsrap.NavDropdown>
//           </ReactBootsrap.Nav>
//           <ReactBootsrap.Nav>
//             <ReactBootsrap.Nav.Link href="#deets">More deets</ReactBootsrap.Nav.Link>
//             <ReactBootsrap.Nav.Link eventKey={2} href="#memes">
//               Dank memes
//       </ReactBootsrap.Nav.Link>
//           </ReactBootsrap.Nav>
//         </ReactBootsrap.Navbar.Collapse>
//       </ReactBootsrap.Navbar>

//       {/* <UserGreeting /> */}
//       {/* <ParentComponent /> */}
//       {/* <EventBind /> */}
//       {/* <ClassClick />
//       <FunctionClick /> */}
//       {/* <Counter /> */}
//       {/* <Page1 name="Bruce" heroName="Batman"><p>This is Children props</p></Page1>
//       <Page1 name="Jean" heroName="Wonder Woman"><button>Action</button></Page1>
//       <Page1 name="Tan" heroName="Ninja Hatori" /> */}
//       {/* <Page2 name="Bruce" heroName="Batman" />
//       <Page2 name="Jean" heroName="Wonder Woman" />
//       <Page2 name="Tan" heroName="Ninja Hatori" /> */}
//       {/* <Page3 /> */}
//       {/* <Page4 /> */}
//     </div>
//   );
// }

// export default App;



import React, { Component } from 'react';
import * as ReactBootsrap from 'react-bootstrap'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Home } from './Home';
import { CardUI } from './CardUI';
import { Contact } from './Contact';
import { NoMatch } from './NoMatch';
import { Layout } from './components/Layout';
import { NavigationBar } from './components/NavigationBar';
import { Jumbotron } from './components/Jumbotron'
import { Page2 } from './components/Page2';

class App extends Component {



  render() {
    return (
      <React.Fragment>
        <Router>
          <NavigationBar />
          <Jumbotron />
          <Layout>
            <Switch>
              <Route exact path="/" component={Home} />
              <Route path="/CardUI" component={CardUI} />
              <Route path="/contact" component={Contact} />
              <Route component={NoMatch} />
            </Switch>
          </Layout>
        </Router>
      </React.Fragment>
    );
  }
}

export default App;